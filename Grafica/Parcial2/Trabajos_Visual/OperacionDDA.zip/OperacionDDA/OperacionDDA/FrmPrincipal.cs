﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using shappes_2d;

namespace OperacionDDA
{
    public partial class FrmPrincipal : Form
    {
        
        int x1 = 20;
        int x2 = 70;
        int y1 = 30;
        int y2 = 120;
        private Color lineaColor = Color.Black;
        OperacionDDA operacionDDA = new OperacionDDA();
        bool dibujar = false;
        string algoritmoActual = "";
        private Timer timerAnimacion = new Timer();
        private int pixelesMostrados = 0;
        public FrmPrincipal()
        {
            InitializeComponent();
            timerAnimacion.Interval = 100;

            timerAnimacion.Tick += TimerAnimacion_Tick;
        }

        private void TimerAnimacion_Tick(object sender, EventArgs e)
        {
            pixelesMostrados += 5;

            if (pixelesMostrados >= operacionDDA.puntosLista.Count)
            {
                pixelesMostrados = operacionDDA.puntosLista.Count;
                timerAnimacion.Stop();
            }

            pictureBox1.Invalidate();
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            int cx = pictureBox1.Width / 2;
            int cy = pictureBox1.Height / 2;
            
            operacionDDA.DibujarPlano(e.Graphics, pictureBox1.Width, pictureBox1.Height, cx, cy);

            if (dibujar)
            {
                if (algoritmoActual == "DDA")
                {
                    operacionDDA.DibujarAnimado( e.Graphics, Color.Blue, pixelesMostrados, cx, cy);
                    MostrarFormula();
                }
                else if (algoritmoActual == "Bresenham")
                {
                    operacionDDA.DibujarAnimado(e.Graphics, Color.Blue, pixelesMostrados, cx, cy);
                    MostrarFormula();
                }
                else if (algoritmoActual == "PuntoMedio")
                {
                    operacionDDA.DibujarAnimado(e.Graphics, Color.Blue, pixelesMostrados, cx, cy);
                    MostrarFormula();
                }

                lstPuntos.Items.Clear();
                lblPasos.Text = $"Pasos: {operacionDDA.getPasos()}";
                foreach (var linea in operacionDDA.puntosLista)
                {
                    lstPuntos.Items.Add(linea);
                }
            }

        }

        private void lstPuntos_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
        }

        private void lblPuntos_Click(object sender, EventArgs e)
        {
        }

        private void btnDibujar_Click(object sender, EventArgs e)
        {
            if (ValidarEntradas())
            {
                /*lstPuntos.Items.Clear();
                algoritmoActual = "DDA";
                dibujar = true;
                pictureBox1.Invalidate();*/
                lstPuntos.Items.Clear();

                operacionDDA.GenerarDDA(x1, y1, x2, y2);

                algoritmoActual = "DDA";
                dibujar = true;

                pixelesMostrados = 0;

                timerAnimacion.Start();

                pictureBox1.Invalidate();
            }
        }

        private void btnBresenham_Click(object sender, EventArgs e)
        {
            if (ValidarEntradas())
            {
                /*lstPuntos.Items.Clear();
                algoritmoActual = "Bresenham";
                dibujar = true;
                pictureBox1.Invalidate();*/
                operacionDDA.GenerarBresenham(x1, y1, x2, y2);

                algoritmoActual = "Bresenham";
                dibujar = true;

                pixelesMostrados = 0;

                timerAnimacion.Start();

                pictureBox1.Invalidate();
            }
        }

        private void btnPuntoMedio_Click(object sender, EventArgs e)
        {
            if (ValidarEntradas())
            {
                /*lstPuntos.Items.Clear();
                algoritmoActual = "PuntoMedio";
                dibujar = true;
                pictureBox1.Invalidate();*/
                operacionDDA.GenerarPuntoMedio(x1, y1, x2, y2);

                algoritmoActual = "PuntoMedio";
                dibujar = true;

                pixelesMostrados = 0;

                timerAnimacion.Start();

                pictureBox1.Invalidate();
            }
        }

        private bool ValidarEntradas()
        {
            if (Validador.Validar<int>(txtX1.Text) &&
                Validador.Validar<int>(txtY1.Text) &&
                Validador.Validar<int>(txtX2.Text) &&
                Validador.Validar<int>(txtY2.Text))
            {
                x1 = int.Parse(txtX1.Text);
                y1 = int.Parse(txtY1.Text);
                x2 = int.Parse(txtX2.Text);
                y2 = int.Parse(txtY2.Text);
                return true;
            }
            else
            {
                MessageBox.Show("Ingresa números enteros válidos para las coordenadas.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            lstPuntos.Items.Clear();
            txtX1.Text = "";
            txtY1.Text = "";
            txtX2.Text = "";
            txtY2.Text = "";
            lblPasos.Text = "Pasos";
            
            algoritmoActual = "";
            dibujar = false;
            rtbFormula.Clear();
            pictureBox1.Invalidate();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void txtX2_TextChanged(object sender, EventArgs e)
        {

        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {

        }

        private void MostrarFormula()
        {
            switch (algoritmoActual)
            {
                case "DDA":
                    rtbFormula.Text =
        @"ALGORITMO DDA

dx = x2 - x1
dy = y2 - y1

pasos = max(|dx|,|dy|)

Xinc = dx / pasos
Yinc = dy / pasos

x = x + Xinc
y = y + Yinc";
                    break;

                case "Bresenham":
                    rtbFormula.Text =
        @"ALGORITMO BRESENHAM

dx = |x2 - x1|
dy = |y2 - y1|

error = dx - dy

e2 = 2 * error

Si e2 > -dy
    error = error - dy

Si e2 < dx
    error = error + dx";
                    break;

                case "PuntoMedio":
                    rtbFormula.Text =
        @"ALGORITMO PUNTO MEDIO

p = 2dy - dx

Si p < 0

    p = p + 2dy

Si p >= 0

    p = p + 2(dy-dx)";
                    break;
            }
        }
    }
}
