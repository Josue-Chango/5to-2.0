export interface Appointment {
  id: string;
  pacienteId: string;
  medicoId: string;
  especialidad: string;
  fecha: string;
  hora: string;
  estado: 'pendiente' | 'confirmada' | 'cancelada' | 'completada';
  descuentoAplicado: boolean;
  createdAt: string;
}

export interface CreateAppointmentRequest {
  medicoId: string;
  especialidad: string;
  fecha: string;
  hora: string;
}

export interface AppointmentSummary {
  medico: string;
  especialidad: string;
  fecha: string;
  hora: string;
}
