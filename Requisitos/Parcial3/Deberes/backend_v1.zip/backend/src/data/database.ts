import { User } from '../models/user.model';
import { Doctor, ScheduleSlot } from '../models/doctor.model';
import { Appointment } from '../models/appointment.model';

export const usuarios: User[] = [
  { id: '1', nombre: 'Juan Pérez', email: 'juan@email.com', password: '123456', tieneSeguro: true, penalizado: false },
  { id: '2', nombre: 'María López', email: 'maria@email.com', password: '123456', tieneSeguro: false, penalizado: false },
  { id: '3', nombre: 'Carlos Ruiz', email: 'carlos@email.com', password: '123456', tieneSeguro: true, penalizado: true },
];

export const doctores: Doctor[] = [
  { id: '1', nombre: 'Dr. Ana García', especialidad: 'Cardiología' },
  { id: '2', nombre: 'Dr. Luis Martínez', especialidad: 'Cardiología' },
  { id: '3', nombre: 'Dr. Sofía Ramírez', especialidad: 'Dermatología' },
  { id: '4', nombre: 'Dr. Pedro Sánchez', especialidad: 'Dermatología' },
  { id: '5', nombre: 'Dr. Laura Torres', especialidad: 'Pediatría' },
  { id: '6', nombre: 'Dr. Andrés Vega', especialidad: 'Pediatría' },
];

export function generarHorarios(medicoId: string, fecha: string): ScheduleSlot[] {
  const slots: ScheduleSlot[] = [];
  const horas = ['08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
                 '14:00', '14:30', '15:00', '15:30', '16:00', '16:30'];
  for (const hora of horas) {
    const ocupado = citas.some(c => c.medicoId === medicoId && c.fecha === fecha && c.hora === hora);
    slots.push({
      id: `${medicoId}-${fecha}-${hora}`,
      medicoId,
      fecha,
      hora,
      estado: ocupado ? 'ocupado' : 'disponible',
    });
  }
  return slots;
}

export const citas: Appointment[] = [];
