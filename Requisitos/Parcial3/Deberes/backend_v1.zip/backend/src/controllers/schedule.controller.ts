import { Request, Response } from 'express';
import { obtenerEspecialidades, obtenerMedicosPorEspecialidad, obtenerHorariosDisponibles } from '../services/schedule.service';

export function listarEspecialidades(_req: Request, res: Response): void {
  res.json(obtenerEspecialidades());
}

export function listarMedicos(req: Request, res: Response): void {
  const especialidad = req.params.especialidad as string;
  const medicos = obtenerMedicosPorEspecialidad(especialidad);
  res.json(medicos);
}

export function verHorarios(req: Request, res: Response): void {
  const { medicoId, fecha } = req.query as { medicoId: string; fecha: string };
  if (!medicoId || !fecha) {
    res.status(400).json({ error: 'medicoId y fecha son requeridos' });
    return;
  }
  const horarios = obtenerHorariosDisponibles(medicoId, fecha);
  res.json(horarios);
}
