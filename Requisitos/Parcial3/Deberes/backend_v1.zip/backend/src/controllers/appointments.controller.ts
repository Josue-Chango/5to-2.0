import { Request, Response } from 'express';
import { crearCita, obtenerCitasPorPaciente } from '../services/appointments.service';
import { enviarConfirmacion } from '../services/notifications.service';
import { doctores, usuarios } from '../data/database';

export function reservarCita(req: Request, res: Response): void {
  const pacienteId = (req as any).userId;
  const cita = crearCita(pacienteId, req.body);
  if ('error' in cita) {
    res.status(400).json({ error: cita.error });
    return;
  }
  const paciente = usuarios.find(u => u.id === pacienteId)!;
  const evento = enviarConfirmacion(cita, paciente.email);
  res.status(201).json({ cita, notificacion: evento });
}

export function listarCitas(req: Request, res: Response): void {
  const pacienteId = (req as any).userId;
  const citas = obtenerCitasPorPaciente(pacienteId);
  res.json(citas);
}
