import { Request, Response } from 'express';
import { login } from '../services/auth.service';

export function loginHandler(req: Request, res: Response): void {
  const { email, password } = req.body;
  if (!email || !password) {
    res.status(400).json({ error: 'Email y contraseña requeridos' });
    return;
  }
  const result = login({ email, password });
  if (!result) {
    res.status(401).json({ error: 'Credenciales inválidas o usuario penalizado' });
    return;
  }
  res.json(result);
}
