import { usuarios } from '../data/database';
import { AuthResponse, LoginRequest, User } from '../models/user.model';

function generarToken(user: User): string {
  return Buffer.from(`${user.id}:${user.email}:${Date.now()}`).toString('base64');
}

export function login(data: LoginRequest): AuthResponse | null {
  const user = usuarios.find(u => u.email === data.email && u.password === data.password);
  if (!user) return null;
  if (user.penalizado) return null;
  const { password, ...userSinPassword } = user;
  return { token: generarToken(user), user: userSinPassword };
}
