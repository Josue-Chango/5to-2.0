import { Appointment } from '../models/appointment.model';

interface NotificationEvent {
  tipo: 'confirmacion' | 'recordatorio' | 'cancelacion';
  destino: string;
  mensaje: string;
  citaId: string;
}

export function enviarConfirmacion(cita: Appointment, emailPaciente: string): NotificationEvent {
  const evento: NotificationEvent = {
    tipo: 'confirmacion',
    destino: emailPaciente,
    mensaje: `Tu cita de ${cita.especialidad} para el ${cita.fecha} a las ${cita.hora} ha sido confirmada.`,
    citaId: cita.id,
  };
  return evento;
}
