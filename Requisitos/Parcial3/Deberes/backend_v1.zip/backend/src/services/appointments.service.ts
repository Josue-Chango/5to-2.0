import { citas, usuarios, doctores } from '../data/database';
import { Appointment, CreateAppointmentRequest } from '../models/appointment.model';

export function crearCita(pacienteId: string, data: CreateAppointmentRequest): Appointment | { error: string } {
  const paciente = usuarios.find(u => u.id === pacienteId);
  if (!paciente) return { error: 'Paciente no encontrado' };
  if (paciente.penalizado) return { error: 'El paciente tiene bloqueos administrativos' };

  const doctor = doctores.find(d => d.id === data.medicoId);
  if (!doctor) return { error: 'Médico no encontrado' };

  const conflicto = citas.some(
    c => c.medicoId === data.medicoId && c.fecha === data.fecha && c.hora === data.hora
  );
  if (conflicto) return { error: 'El horario ya está ocupado' };

  const cita: Appointment = {
    id: `CITA-${Date.now()}`,
    pacienteId,
    medicoId: data.medicoId,
    especialidad: data.especialidad,
    fecha: data.fecha,
    hora: data.hora,
    estado: 'pendiente',
    descuentoAplicado: paciente.tieneSeguro,
    createdAt: new Date().toISOString(),
  };

  citas.push(cita);
  return cita;
}

export function obtenerCitasPorPaciente(pacienteId: string): Appointment[] {
  return citas.filter(c => c.pacienteId === pacienteId);
}
