import { doctores, generarHorarios } from '../data/database';
import { Doctor, ScheduleSlot } from '../models/doctor.model';

export function obtenerEspecialidades(): string[] {
  return [...new Set(doctores.map(d => d.especialidad))];
}

export function obtenerMedicosPorEspecialidad(especialidad: string): Doctor[] {
  return doctores.filter(d => d.especialidad === especialidad);
}

export function obtenerHorariosDisponibles(medicoId: string, fecha: string): ScheduleSlot[] {
  const slots = generarHorarios(medicoId, fecha);
  return slots.filter(s => s.estado === 'disponible');
}
