import { Router } from 'express';
import { authMiddleware } from '../middleware/auth.middleware';
import { reservarCita, listarCitas } from '../controllers/appointments.controller';

const router = Router();
router.use(authMiddleware);
router.post('/reservar', reservarCita);
router.get('/', listarCitas);

export default router;
